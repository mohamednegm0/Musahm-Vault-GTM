# Message House — Musahm + Musahm Vault

---

## Musahm — Core Governance Platform

### Hero Statement

**English:**
> **Every board decision, properly governed. Every shareholder communication, properly recorded. Musahm is the governance platform Saudi companies trust.**

**Arabic:**
> **كل قرار مجلس إدارة، محوكم بشكل صحيح. كل تواصل مع المساهمين، موثّق بدقة. مساهم هي منصة الحوكمة التي تثق بها الشركات السعودية.**

---

### 3 Supporting Proof Points

**Proof Point 1: Complete Governance Coverage**
Musahm is the only KSA platform that covers the full governance lifecycle in a single product — board meetings, committee management, general assemblies, electronic voting, e-signatures, shareholder registry, contract documentation, and policies management. No feature gaps. No need for a second tool.

> مساهم هي المنصة السعودية الوحيدة التي تغطي دورة الحوكمة الكاملة في منتج واحد — من اجتماعات مجلس الإدارة إلى سجلات المساهمين.

**Proof Point 2: Built for Saudi Regulations**
Designed from day one for Saudi corporate law compliance — supporting both listed companies (هيئة سوق المال requirements) and unlisted companies (LLCs and closed joint-stock). E-signatures comply with نظام التعاملات الإلكترونية. Not a foreign product adapted for KSA — a Saudi product built for Saudi law.

> مصممة من اليوم الأول للامتثال لنظام الشركات السعودي — تدعم الشركات المدرجة وغير المدرجة والشركات ذات المسؤولية المحدودة.

**Proof Point 3: Mobile-Ready for Modern Boards**
Full-featured iOS and Android apps. Board members can review agendas, vote electronically, sign documents, and access meeting materials from their phones. Because Saudi executives make decisions from everywhere — not just the boardroom.

> تطبيقات كاملة للأيفون والأندرويد. أعضاء مجلس الإدارة يراجعون ويصوتون ويوقعون من هواتفهم.

---

### 3 Objection Handlers

#### Objection 1: "نستخدم واتساب وماشي الحال" / "We use WhatsApp and it works fine"

**Response framework:**
WhatsApp works until it doesn't. When a regulatory auditor asks for the board resolution from March 2024, can you find it in your group chat? When a board member leaves and you need to revoke their access to confidential documents, can you do it in WhatsApp? When shareholders dispute a vote, do you have a tamper-proof record?

WhatsApp is a messaging app. Governance needs an audit trail, access control, and legal proof. Musahm gives you all three — and your board members can still get notifications on their phones, the way they're used to.

>واتساب يعمل حتى لا يعمل. عندما يطلب المدقق قرار مجلس الإدارة من مارس 2024، هل تجده في المجموعة؟ عندما يغادر عضو هل تستطيع سحب صلاحياته؟ واتساب تطبيق رسائل. الحوكمة تحتاج سجل تدقيق وصلاحيات وإثبات قانوني — وهذا ما يوفره مساهم.

---

#### Objection 2: "غالي على حجمنا" / "Too expensive for our size"

**Response framework:**
How much does a governance failure cost? One disputed board resolution, one lost shareholder document, one compliance violation — any of these can cost more than years of Musahm subscription. Musahm is priced for SMBs, not enterprises. The question isn't "can we afford Musahm?" — it's "can we afford what happens without it?"

For context: a single legal dispute over an undocumented board decision can cost SAR 50,000+ in legal fees (estimate — ⚠️ validate with Musahm legal team). Musahm costs a fraction of one prevented dispute.

> كم تكلفة فشل الحوكمة؟ نزاع واحد على قرار غير موثّق يكلف أكثر من سنوات اشتراك مساهم. مساهم مسعّر للشركات الصغيرة والمتوسطة — السؤال ليس "هل نتحمل تكلفة مساهم؟" بل "هل نتحمل تكلفة عدم وجوده؟"

⚠️ NEEDS CLIENT INPUT: Specific pricing needed to make this objection handler concrete. Recommendation: include a "starting from SAR X/month" figure.

---

#### Objection 3: "أعضاء مجلسنا ما يعرفون تقنية" / "Our board is not tech-savvy"

**Response framework:**
That's exactly why we built Musahm the way we did. Your board members don't need to be tech-savvy — they need to open an app, read an agenda, and tap "approve." That's it. We designed the interface for board members who have never used governance software, not for IT departments.

The onboarding takes 15 minutes. The web interface is clean, Arabic-first, and designed for people who are comfortable with WhatsApp — not IT professionals.

> لذلك بالتحديد بنينا مساهم بهذه الطريقة. أعضاء المجلس لا يحتاجون خبرة تقنية — يفتحون المنصة ويقرأون جدول الأعمال ويضغطون "موافق." الواجهة عربية أولاً ومصممة للمستخدمين الذين يرتاحون مع واتساب — وليس متخصصي تقنية المعلومات. التهيئة تستغرق 15 دقيقة.

---

---

## Musahm Vault — Document Management System

### Hero Statement

**English:**
> **Your company's most important documents — protected, organized, and connected to every governance decision. Musahm Vault is the DMS built for Saudi boardrooms.**

**Arabic:**
> **أهم وثائق شركتك — محمية ومنظمة ومرتبطة بكل قرار حوكمة. مساهم Vault هو نظام إدارة الوثائق المبني لمجالس الإدارة السعودية.**

---

### 3 Supporting Proof Points

**Proof Point 1: Documents Live Where Governance Happens**
Vault shares the same user accounts and authentication as Musahm through GRC SSO integration. Your team logs in once. Governance workspaces are pre-created — Board Meetings, Decisions, Committees, Contracts, Policies & Regulations — mirroring how your governance is structured. Documents live in the context of your governance, not in a generic file dump.

> Vault يشارك نفس حسابات المستخدمين والمصادقة مع مساهم. فريقك يسجّل الدخول مرة واحدة. مساحات العمل مُعدّة مسبقاً — اجتماعات المجلس والقرارات واللجان والعقود والسياسات. وثائقك في سياق حوكمتك، لا في مخزن ملفات عشوائي.

**Proof Point 2: Granular Access Control + Audit Trail**
Five hierarchical roles (Viewer → Commenter → Editor → Organizer → Admin) plus per-document ACLs for fine-grained sharing. Audit logs capture every action with user identity, IP address, and timestamps. External parties receive documents via OTP-verified access with watermarked copies — so you always know who has what. When someone leaves, remove their workspace membership and their access is gone.

> خمسة مستويات صلاحيات (عارض ← معلق ← محرر ← منظم ← مدير) بالإضافة لصلاحيات دقيقة لكل وثيقة. سجل تدقيق يسجّل كل عملية. الأطراف الخارجية تستلم وثائق عبر كلمة مرور مؤقتة مع علامة مائية. عندما يغادر شخص، أزل عضويته ويختفي وصوله.

**Proof Point 3: Workflows + Version Control, Not Just Storage**
Vault goes beyond file storage with automated workflows (approval chains that gate document publishing), version control (full version history per document), check-in/check-out locking, document type classification, and AI-powered field extraction. It's a governed document lifecycle, not a folder on a shared drive.

> Vault يتجاوز تخزين الملفات — سير عمل آلي (سلاسل موافقة قبل نشر الوثائق)، تحكم بالإصدارات، قفل تحرير، تصنيف أنواع الوثائق، واستخراج ذكي للحقول. دورة حياة وثائق محوكمة، وليس مجلداً على قرص مشترك.

---

### 3 Objection Handlers

#### Objection 1: "نستخدم SharePoint" / "We already use SharePoint"

**Response framework:**
SharePoint is a general-purpose file storage tool. It doesn't know what a board resolution is. It doesn't connect documents to meeting minutes. It doesn't understand Saudi governance workflows. You can store files in SharePoint the same way you can store files on a USB drive — but neither one was built for governance.

Vault was built specifically for the documents that matter in a governed company — board materials, shareholder agreements, compliance filings, signed resolutions. It connects them to decisions, tracks who accessed them, and maintains the audit trail your regulator expects. SharePoint stores files. Vault governs documents.

> شيربوينت أداة تخزين عامة. لا يعرف ما هو قرار مجلس الإدارة ولا يربط الوثائق بمحاضر الاجتماعات. Vault بُني خصيصاً لوثائق الحوكمة — يربطها بالقرارات ويتتبع الوصول ويحفظ سجل التدقيق الذي يتوقعه المنظم. شيربوينت يخزّن ملفات. Vault يحكم وثائق.

---

#### Objection 2: "ما عندنا وثائق كثيرة" / "We don't have that many documents"

**Response framework:**
Every company has more governance documents than they think. Board minutes, shareholder resolutions, company policies, committee reports, signed contracts, regulatory filings, organizational charts, bylaws — these exist in every company, even a 20-person LLC. The question is: where are they right now?

If the answer is "in someone's email" or "on Ahmed's laptop" — that's exactly the problem Vault solves. It's not about volume. It's about knowing where your critical documents are, who can access them, and being able to produce them when asked.

> كل شركة لديها وثائق حوكمة أكثر مما تظن — محاضر اجتماعات، قرارات، عقود، سياسات، تقارير لجان. السؤال: أين هي الآن؟ إذا الجواب "في إيميل أحمد" أو "على لابتوب خالد" — هذه بالتحديد المشكلة التي يحلها Vault.

---

#### Objection 3: "غالي على حجمنا" / "Too expensive for a DMS"

**Response framework:**
Compare Vault's cost to any of these alternatives:
- Hiring an IT consultant to set up SharePoint governance workflows: SAR 30,000+
- Ebana or similar custom DMS development: SAR 100,000+ implementation, months to deploy
- The cost of a single data breach from documents shared in WhatsApp with a former employee who still has access: immeasurable

Vault is SaaS — no implementation fees, no consultants, no hardware. It's already integrated with your Musahm account. Turn it on and start uploading. The cost of NOT having document governance is always higher.

> قارن تكلفة Vault مع البدائل: استشاري لإعداد شيربوينت (30,000+ ريال)، تطوير نظام مخصص (100,000+ ريال وأشهر)، أو تكلفة تسريب بيانات من وثائق مشاركة عبر واتساب مع موظف سابق ما زال يملك الوصول. Vault اشتراك شهري — بدون رسوم تأسيس ولا استشاريين. مدمج مع حساب مساهم. شغّله وابدأ.

⚠️ NEEDS CLIENT INPUT: Vault pricing needed. Recommendation: anchor as "included with Musahm subscription" if possible, or "starting from SAR X/month" as an add-on.
