# Social Media Posts — Musahm Vault Launch

---

## LinkedIn Post (Company Page)

### Arabic Version

**أين وثائق شركتك الآن؟**

في إيميل المدير المالي؟ في مجموعة واتساب؟ على لابتوب موظف غادر الشركة من 6 أشهر؟

هذا الواقع في كثير من الشركات السعودية — ونعرف لأننا نعمل معها يومياً عبر مساهم.

اليوم نطلق **مساهم Vault** — نظام إدارة وثائق مبني خصيصاً للحوكمة:

◾ تنظيم ذكي مع تصنيف ووسوم
◾ صلاحيات حسب الأدوار — تحكم كامل بالوصول
◾ سجل تدقيق لكل عملية
◾ تكامل مع منصة مساهم للحوكمة — نفس الحساب، نفس المستخدمين

Vault ليس مخزن ملفات. Vault يعرف لماذا كل وثيقة موجودة ومن يحق له الاطلاع عليها.

المرحلة التجريبية متاحة الآن لعملاء مساهم الحاليين.

احصلوا على وصولكم التجريبي: [رابط]

#مساهم #Vault #حوكمة_الشركات #إدارة_الوثائق #رؤية2030 #تحول_رقمي #SaudiTech #GRC #Musahm

---

### English Version

**Where are your company's most important documents right now?**

In the CFO's inbox? In a WhatsApp group? On the laptop of someone who left 6 months ago?

This is the reality for too many Saudi companies — and we know because we work with them daily through Musahm.

Today we're launching **Musahm Vault** — a document management system built specifically for governance:

◾ Smart organization with folders and metadata tagging
◾ Role-based permissions — full access control
◾ Audit trail for every action
◾ Direct integration with Musahm — same account, same users

Vault isn't file storage. Vault knows WHY every document exists and WHO should see it.

Beta access is now open for existing Musahm clients.

Request your beta access: [link]

#Musahm #Vault #CorporateGovernance #DocumentManagement #Vision2030 #DigitalTransformation #SaudiTech #GRC #KSA

---

## Twitter/X Posts

### Arabic Version (274 characters)

```
وثائق شركتك مبعثرة بين الإيميل والواتساب والأجهزة الشخصية؟

أطلقنا مساهم Vault — نظام إدارة وثائق مدمج مع حوكمتكم. صلاحيات. تدقيق. تنظيم.

المرحلة التجريبية متاحة الآن.

[رابط]

#مساهم #حوكمة_الشركات
```

### English Version (269 characters)

```
Your company docs are scattered across email, WhatsApp, and personal devices.

Introducing Musahm Vault — a DMS built for governance. Permissions. Audit trails. Organization.

Beta now open for Musahm clients.

[link]

#Musahm #CorporateGovernance #SaudiTech
```

---

## Posting Schedule Recommendation

| Platform | Day | Time (AST) | Rationale |
|---|---|---|---|
| LinkedIn | Sunday | 09:00 AM | KSA business week start, peak B2B LinkedIn engagement |
| Twitter/X | Sunday | 12:00 PM | Post-lunch engagement peak in KSA |
| LinkedIn (repost/boost) | Tuesday | 10:00 AM | Mid-week reinforcement |
| Twitter/X (reminder) | Wednesday | 11:00 AM | Final week push before weekend |

⚠️ NEEDS CLIENT INPUT: Musahm LinkedIn company page and Twitter/X handle access, beta signup landing page URL.
