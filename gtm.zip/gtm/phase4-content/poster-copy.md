# Poster / Visual Ad Copy — Musahm Vault

## Text Layer for Design Team

---

## Arabic Version

| Element | Text | Constraint |
|---|---|---|
| **Headline** | وثائقك. محمية. محوكمة. | 5 words max |
| **Subheadline** | نظام إدارة الوثائق المدمج مع منصة مساهم للحوكمة | 10 words max |
| **Body** | صلاحيات حسب الأدوار. سجل تدقيق شامل. سير عمل آلي. جاهز في دقائق. | 15 words max |
| **CTA Button** | اطلب وصولك التجريبي | — |
| **Legal/Brand Line** | مساهم — حوكمة الشركات السعودية | — |

---

## English Version

| Element | Text | Constraint |
|---|---|---|
| **Headline** | Your docs. Secured. Governed. | 5 words max |
| **Subheadline** | The DMS built for Saudi corporate governance. | 10 words max |
| **Body** | Role-based permissions. Full audit trail. Automated workflows. Ready in minutes. | 15 words max |
| **CTA Button** | Request Beta Access | — |
| **Legal/Brand Line** | Musahm — Saudi Corporate Governance | — |

---

## Design Direction Notes (for design team)

| Aspect | Guidance |
|---|---|
| **Primary visual** | Abstract representation of document protection — shield icon enclosing document layers, or vault door with organized files visible inside |
| **Color scheme** | Follow chosen brand concept palette. Ensure strong contrast for text readability. |
| **Layout** | Headline top-center (large), subheadline below (medium), body text center (small), CTA button bottom-center (prominent), brand line bottom-right (small) |
| **RTL consideration** | Arabic version must be fully RTL — right-aligned text, reversed layout elements |
| **Logo placement** | Musahm logo top-right (Arabic) or top-left (English). Vault sub-brand lockup below main logo. |
| **Formats needed** | 1080×1080 (social square), 1200×628 (LinkedIn/Twitter landscape), 1080×1920 (story/vertical), print A4 |
| **No-go** | No stock photos of generic offices. No handshake imagery. No globe icons. Keep it clean and product-focused. |

⚠️ NEEDS CLIENT INPUT: Final Vault sub-brand logo/lockup, approved brand concept selection (Trust-Heritage, Modern-Digital, or KSA-Native-Tech), and format priority for first production run.
