# Launch Email — Musahm Vault Beta Announcement

## To: Existing Musahm Clients
## Purpose: Invite to Vault beta access

---

## Subject Line Options

1. **وثائق شركتك تستحق حماية أفضل — تعرّف على Vault** (Your company documents deserve better protection — meet Vault)
2. **جديد من مساهم: نظام إدارة الوثائق الذي طالبتم به** (New from Musahm: the document management system you asked for)
3. **أنتم أول من يحصل على Vault — الوصول التجريبي متاح الآن** (You're the first to get Vault — beta access available now)

---

## Email Body — Arabic Version

**الموضوع:** وثائق شركتك تستحق حماية أفضل — تعرّف على Vault

---

[شعار مساهم]

السادة الكرام في [اسم الشركة]،
عناية [اسم جهة الاتصال]،

منذ انضمامكم لمساهم وأنتم تديرون اجتماعات مجلس الإدارة وقرارات الحوكمة باحترافية. لكننا نعلم أن الحوكمة لا تقتصر على الاجتماعات — الوثائق هي الأساس.

لذلك بنينا **مساهم Vault**.

Vault هو نظام إدارة الوثائق المصمم خصيصاً لسياق الحوكمة السعودي — مرتبط مباشرةً بمنصة مساهم التي تعرفونها وتثقون بها.

**ما الذي يقدمه Vault:**

- **تنظيم ذكي** — مساحات عمل ووسوم وأنواع وثائق مخصصة
- **صلاحيات حسب الأدوار** — خمسة مستويات من عارض إلى مدير، مع تحكم بالوصول لكل وثيقة
- **سجل تدقيق شامل** — كل عملية مسجّلة بالمستخدم وعنوان IP والتفاصيل
- **مشاركة آمنة** — دعوات بالبريد، وصول خارجي عبر كلمة مرور مؤقتة مع علامة مائية
- **سير عمل آلي** — موافقات ومراجعات تلقائية قبل نشر أي وثيقة

بصفتكم من عملاء مساهم المميزين، ندعوكم لتكونوا من أوائل من يجرّب Vault قبل إطلاقه رسمياً.

**الأماكن محدودة في المرحلة التجريبية.**

[زر: احصل على وصول تجريبي]

نتطلع لمساعدتكم في حماية وثائق شركتكم بنفس الثقة التي تديرون بها حوكمتكم.

مع التقدير،
فريق مساهم

---

## Email Body — English Version

**Subject:** Your company documents deserve better protection — meet Vault

---

[Musahm Logo]

Dear [Client Name],

Since joining Musahm, you've been managing your board meetings and governance decisions with real professionalism. But we know governance doesn't stop at meetings — documents are the foundation.

That's why we built **Musahm Vault**.

Vault is a document management system designed specifically for Saudi governance context — directly connected to the Musahm platform you already know and trust.

**What Vault delivers:**

- **Smart organization** — workspaces, tags, and customizable document types
- **Role-based permissions** — five levels from Viewer to Admin, plus per-document access control
- **Complete audit trail** — every action logged with user, IP address, and details
- **Secure sharing** — email invitations, OTP-based external access with watermarked documents
- **Automated workflows** — approval and review workflows that gate document publishing

As one of our valued Musahm clients, we're inviting you to be among the first to experience Vault before its official launch.

**Beta spots are limited.**

[Button: Request Beta Access]

We look forward to helping you protect your company's documents with the same trust you bring to your governance.

Warm regards,
The Musahm Team

---

## CTA Specifications

| Element | Arabic | English |
|---|---|---|
| **Button text** | احصل على وصول تجريبي | Request Beta Access |
| **Button link** | ⚠️ NEEDS CLIENT INPUT: Landing page URL | ⚠️ NEEDS CLIENT INPUT: Landing page URL |
| **Button color** | Primary brand green (`#006C35` or as per chosen brand concept) | Same |
| **Below CTA** | أو تواصل معنا عبر واتساب: [رقم] | Or reach us on WhatsApp: [number] |

⚠️ NEEDS CLIENT INPUT: WhatsApp support number, beta signup landing page URL, and sender email address.
