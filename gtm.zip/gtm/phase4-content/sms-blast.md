# SMS Blast — Musahm Vault Beta Announcement

> **Encoding note:** Arabic text is encoded as UCS-2 in SMS, which limits a single SMS segment to **70 characters** (not 160). Messages exceeding 70 characters are split into multiple segments at ~67 characters each (due to concatenation headers). Plan costs accordingly.

---

## Version 1: Formal Arabic — Single SMS (67 chars)

**Segment count: 1 SMS**
**Character count: 65**

```
مساهم Vault متاح تجريبياً. أنتم أول المدعوين. سجّلوا الآن: [رابط]
```

**Translation:** Musahm Vault is available in beta. You're the first invited. Register now: [link]

---

## Version 1B: Formal Arabic — Extended (2 segments, use if budget allows)

**Segment count: 2 SMS segments**
**Character count: 118**

```
مساهم Vault متاح الآن تجريبياً — نظام إدارة وثائق مدمج مع حوكمتكم. بصفتكم عملاء مساهم، أنتم أول المدعوين. سجّلوا الآن: [رابط]
```

**Cost:** 2× per-message rate. Use for Wave 1 high-value clients only.

---

## Version 2: Modern English — Single SMS

**Segment count: 1 SMS** (English = GSM-7 encoding, 160 char limit)
**Character count: 152**

```
Musahm Vault is live in beta. Your governance docs — organized, secured, and audit-ready. As a Musahm client, you get early access. Sign up: [link]
```

---

## Deployment Notes

| Parameter | Recommendation |
|---|---|
| **Timing** | Sunday 10:00 AM AST (KSA business week start) |
| **Sender ID** | "Musahm" (branded sender) |
| **Target** | Primary contacts from Musahm client accounts (board secretaries first, then CEOs) |
| **Follow-up** | If no response within 72 hours, send email version as follow-up |
| **Opt-out** | Include opt-out mechanism per KSA CITC regulations |
| **Opt-in** | Verify recipients have opted into marketing communications before sending. KSA CITC regulations penalize unsolicited commercial SMS. |
| **Cost model** | Arabic SMS = 2 segments per extended message (UCS-2). English SMS = 1 segment (GSM-7). Budget accordingly. |
| **Coordination** | This SMS is part of a launch sequence: SMS (Sunday AM) → Email follow-up (Wednesday if no response) → WhatsApp (following Sunday). See `launch-checklist.md` for full sequence. |

⚠️ NEEDS CLIENT INPUT: SMS gateway/service provider, branded sender ID registration status, final landing page URL for [رابط]/[link], and opt-in verification status of client contact list.
