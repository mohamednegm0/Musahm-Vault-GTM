# Product Video Script — Musahm Vault Launch
## Duration: 75 seconds | Bilingual (Arabic VO + English subtitles)

---

## Tone & Style Guide

| Aspect | Direction |
|---|---|
| **Overall tone** | Warm, confident, unhurried. Not a startup hype video — an institutional product introduction. |
| **VO style** | Male or female professional Arabic narrator. MSA with natural Khaleeji rhythm. Calm authority. |
| **Music** | Clean, minimal electronic underscore. No drums until the product reveal. Builds subtly. Think: corporate documentary, not tech ad. |
| **Visual style** | Mix of motion graphics (product UI animations) and live-action-style renders (modern Saudi office environment). Clean, bright, professional. |
| **Subtitles** | English subtitles throughout. Arabic caption overlay for key statistics. |
| **Aspect ratio** | 16:9 primary (YouTube/LinkedIn), 9:16 cut for social stories/reels |

---

## Scene-by-Scene Script

### Scene 1 | The Problem (0:00 – 0:18)

| Element | Content |
|---|---|
| **VO (Arabic)** | كل شركة سعودية عندها وثائق مهمة — عقود، قرارات مجلس إدارة، سياسات، محاضر اجتماعات. لكن وين هي؟ في إيميلات قديمة. في مجموعات واتساب. على أجهزة شخصية. ما أحد يعرف مين اطّلع عليها... أو مين ما زال يقدر يوصلها. |
| **English subtitle** | Every Saudi company has critical documents — contracts, board decisions, policies, minutes. But where are they? In old emails. In WhatsApp groups. On personal devices. No one knows who's seen them... or who still has access. |
| **On-screen text** | عقود ↓ واتساب ↓ إيميل ↓ ؟ (animated, scattered across screen, then fade to chaos) |
| **Visual direction** | Open on a dark, cluttered desktop. Document icons scattered across WhatsApp chat bubbles, email threads, personal laptop screens. Icons multiply, overlap, create visual anxiety. Colors are muted, overwhelmed. |

---

### Scene 2 | The Stakes (0:18 – 0:28)

| Element | Content |
|---|---|
| **VO (Arabic)** | وثيقة ضايعة ممكن توقف صفقة. وصول غير مصرّح ممكن يكلّف الشركة سمعتها. ومع تزايد متطلبات الامتثال في المملكة — ما في مجال للارتجال. |
| **English subtitle** | A lost document can stall a deal. Unauthorized access can cost a company its reputation. With growing compliance requirements in the Kingdom — there's no room for improvisation. |
| **On-screen text** | (no overlay — let the VO and visuals speak) |
| **Visual direction** | Brief, impactful cuts: a document icon with a red "X" (lost), a lock icon cracking (breach), a regulatory seal stamping "non-compliant." Quick, 2-second cuts. Tension peaks. |

---

### Scene 3 | The Solution Reveal (0:28 – 0:42)

| Element | Content |
|---|---|
| **VO (Arabic)** | نقدّم لكم مساهم Vault — نظام إدارة الوثائق المبني لسياق الحوكمة. |
| **English subtitle** | Introducing Musahm Vault — the document management system built for governance. |
| **On-screen text** | مساهم VAULT (logo reveal, large, centered) |
| **Visual direction** | Hard cut to clean white/green screen. Vault logo animates in with confident motion — not flashy, decisive. Music shifts: subtle bass note, clean electronic pulse begins. The chaos from Scene 1 is replaced by ordered calm. Brief product UI flythrough showing the dashboard — clean, organized, professional. |

---

### Scene 4 | Key Features (0:42 – 1:00)

| Element | Content |
|---|---|
| **VO (Arabic)** | تنظيم ذكي — مساحات عمل ووسوم وبحث متقدم يوصلّك لأي وثيقة في ثوانٍ. صلاحيات حسب الأدوار — خمسة مستويات من عارض إلى مدير. سجل تدقيق شامل — كل عملية مسجّلة ومؤرخة. والأهم — سير عمل آلي يضمن موافقة الأشخاص المعنيين قبل نشر أي وثيقة. |
| **English subtitle** | Smart organization — workspaces, tags, and search that finds any document in seconds. Role-based permissions — five levels from Viewer to Admin. Complete audit trail — every action logged and timestamped. And most importantly — automated workflows ensure the right people approve before any document goes live. |
| **On-screen text** | Feature 1: تنظيم ذكي / Smart Organization | Feature 2: صلاحيات / Permissions | Feature 3: سجل تدقيق / Audit Trail | Feature 4: سير عمل / Workflows (each appears as an icon + label during its mention) |
| **Visual direction** | Product UI demonstrations — real screens, real interactions. Feature 1: workspace explorer showing organized folders and tagged documents. Feature 2: permissions panel showing role dropdown (Viewer → Admin). Feature 3: audit log page with timestamped entries and user details. Feature 4: workflow editor canvas (React Flow) with approval nodes connected. Clean, bright, professional. |

> **Production note:** All UI shown in this scene must be captured from the actual Vault product. The features demonstrated here (workspace organization, role-based membership, audit log view, workflow editor) all exist in the current build. Do NOT mock up features that are not in the product.

---

### Scene 5 | The Complete Stack (1:00 – 1:10)

| Element | Content |
|---|---|
| **VO (Arabic)** | مساهم للحوكمة. Vault للوثائق. منصة واحدة لكل ما تحتاجه شركتك. |
| **English subtitle** | Musahm for governance. Vault for documents. One platform for everything your company needs. |
| **On-screen text** | مساهم + VAULT = حوكمة كاملة (animated equation) |
| **Visual direction** | Two product icons (Musahm shield + Vault lock) animate from opposite sides of the screen, merge in the center with a satisfying lock/click motion. The combined icon sits on a clean gradient background. Simple. Powerful. Complete. |

---

### Scene 6 | CTA (1:10 – 1:18)

| Element | Content |
|---|---|
| **VO (Arabic)** | المرحلة التجريبية متاحة الآن لعملاء مساهم. احجز مكانك اليوم. |
| **English subtitle** | Beta access is now open for Musahm clients. Reserve your spot today. |
| **On-screen text** | احصل على وصولك التجريبي / Request Beta Access | [URL] | شعار مساهم + Vault |
| **Visual direction** | CTA card animates in, clean and centered. QR code on one side, URL on the other. Musahm + Vault logos at bottom. Hold for 3 seconds. Music resolves to a clean finish — no lingering fade, a confident end. |

---

## Production Notes

| Aspect | Specification |
|---|---|
| **Total duration** | 75–80 seconds (tight, no padding) |
| **Deliverable formats** | 16:9 (YouTube, LinkedIn, website), 9:16 (Instagram Reels, TikTok, Snapchat), 1:1 (Twitter/X, LinkedIn feed) |
| **Subtitle file** | Separate SRT in Arabic and English |
| **Thumbnail** | Vault logo + "وثائقك. محمية. محوكمة." on clean branded background |
| **YouTube metadata** | Title: مساهم Vault — نظام إدارة الوثائق للحوكمة | Description: see social-posts.md content | Tags: مساهم, Vault, حوكمة, إدارة وثائق, DMS, السعودية |
| **End screen** | YouTube subscribe button + link to Musahm website + link to beta signup |

⚠️ NEEDS CLIENT INPUT: Final product UI screenshots/recordings for Scene 4, Vault logo lockup, voiceover talent selection, and production timeline.
