# 16-Channel Launch Checklist — Musahm Vault
## KSA-Prioritized Launch Sequence

---

## Timeline Legend

| Code | Timing |
|---|---|
| **W-4** | 4 weeks before launch |
| **W-2** | 2 weeks before launch |
| **W-1** | 1 week before launch |
| **L** | Launch day |
| **L+1** | 1 week after launch |
| **L+2** | 2 weeks after launch |

---

## Launch Channels

| # | Channel | Action | Owner Role | Timing |
|---|---|---|---|---|
| 1 | **Direct Email to Musahm Clients** | Send Vault beta invitation email (see launch-email.md) to all Wave 1 scored clients. Personalize opener per client. Follow up with non-responders after 72 hours. | Marketing Manager + Account Manager | W-1 (Wave 1), L (Wave 2), L+2 (Wave 3) |
| 2 | **SMS Blast** | Send formal Arabic SMS (see sms-blast.md) to primary contacts of all current Musahm clients. Time for Sunday 10:00 AM AST. | Marketing Manager | L |
| 3 | **WhatsApp Business Broadcast** | Send personalized WhatsApp message to key client contacts (board secretaries, CEOs). Include Vault overview + beta signup link. Use WhatsApp Business broadcast list (not group). | Account Manager / Customer Success | W-1 (VIP clients), L (all clients) |
| 4 | **LinkedIn Company Page** | Publish Vault announcement post (see social-posts.md). Pin to top of company page. Update company page description to include Vault. Schedule 2 follow-up posts in L+1 and L+2. | Social Media Manager | L (announcement), L+1 (feature spotlight), L+2 (testimonial/case study) |
| 5 | **Twitter/X (@Musahmksa)** | Publish Vault announcement tweet (see social-posts.md). Pin tweet. Schedule 3 follow-up tweets over 2 weeks: feature highlight, client reaction, beta extension reminder. | Social Media Manager | L, L+1 (×2), L+2 |
| 6 | **YouTube (musahmofficial)** | Upload Vault product video (see video-script.md). Optimize title/description/tags for Arabic + English search. Add end screen with subscribe + beta link. Create a 15-second teaser cut for social. | Marketing Manager + Video Production | W-1 (teaser on social), L (full video) |
| 7 | **In-app Notification (Musahm Users)** | ⚠️ Requires engineering work: build an in-app announcement banner/notification system. Current Vault frontend has Toast notifications but no persistent announcement banner. Fallback: use existing email/SMS channels if in-app notification cannot be built by launch. | Product Manager + Engineering | W-2 (spec), W-1 (build), L (trigger) |
| 8 | **App Store Update Notes** | ⚠️ Verify: This assumes Musahm mobile apps (iOS/Android) exist with Vault functionality. If mobile apps exist but Vault is web-only, update App Store description to mention Vault web access. If no mobile apps, skip this channel entirely. | Marketing Manager + Mobile Dev | W-1 (submit for review), L (live) |
| 9 | **Arabic Tech Press** | Pitch exclusive story to Argaam (أرقام) and StartupScene ME. Provide: press release, product screenshots, key differentiators, founder/CEO quote. Offer exclusive early access for journalists. | PR / Communications | W-2 (pitch), W-1 (exclusive), L (broad distribution) |
| 10 | **Press Release (Bilingual)** | Distribute bilingual press release via Saudi newswire (e.g., ZAWYA, AMEinfo). Include: product announcement, KSA governance context, Vision 2030 alignment, beta access details, CEO quote. | PR / Communications | L |
| 11 | **Google Ads (Arabic KSA)** | Launch search campaign targeting Arabic keywords: إدارة وثائق, حوكمة الشركات, نظام أرشفة, DMS سعودي. Geo-target: KSA only. Landing page: Vault product page with beta signup. | Performance Marketing | L (launch), ongoing optimization |
| 12 | **Partner/Reseller Outreach** | Brief existing Musahm partners/resellers on Vault. Provide: partner sales sheet, demo access, commission structure for Vault referrals. Schedule partner webinar for demo + Q&A. | Business Development | W-2 (brief), W-1 (partner webinar), L (active selling) |
| 13 | **Webinar / Live Demo Session** | Host 30-minute live demo webinar for interested Musahm clients. Arabic language. Show: onboarding, upload, share, permissions, audit trail. Q&A at end. Record and publish to YouTube. | Product Manager + Customer Success | L+1 (first session), L+2 (repeat for stragglers) |
| 14 | **KSA Business Associations** | Reach out to Monsha'at (منشآت) and local Chambers of Commerce to feature Vault in their SMB digitization resources or newsletters. Position as a Vision 2030 aligned Saudi product for SME governance. | Business Development / PR | W-4 (outreach), timeline depends on their response |
| 15 | **Saudi Board Directors Institute / CMA Events** | Attend or sponsor relevant governance events. More targeted than Product Hunt for reaching actual Saudi governance buyers. Contact Saudi Board Directors Institute, CMA-related LinkedIn groups, or governance-focused conferences in Riyadh. | Business Development | W-4 (identify events), ongoing |
| 16 | **Referral Program Launch** | ⚠️ Requires engineering: referral code generation, tracking, and reward logic do not exist in the current codebase. **Phase this for L+4 minimum** — do not promise referral functionality at launch. Simpler alternative for launch: manual referral tracking via a Google Form + CRM, with rewards processed manually. | Marketing Manager + Engineering | L+4 (if engineering capacity allows) |

---

## Pre-Launch Checklist (Must Complete Before Any Channel Goes Live)

| # | Item | Owner | Status |
|---|---|---|---|
| 1 | Vault product page live on musahm.com (Arabic + English) | Web Dev + Marketing | ⬜ |
| 2 | Beta signup form/landing page functional and tested | Web Dev + Marketing | ⬜ |
| 3 | Vault onboarding flow tested with 3+ internal users | Product + QA | ⬜ |
| 4 | User documentation published (Sections 1–3 minimum) | Technical Writer | ⬜ |
| 5 | Product video produced and approved | Video Production + Marketing | ⬜ |
| 6 | All social copy approved by brand/legal | Marketing + Legal | ⬜ |
| 7 | Press release approved by CEO | PR + CEO | ⬜ |
| 8 | Google Ads campaign built and ready to activate | Performance Marketing | ⬜ |
| 9 | In-app notification configured and staged | Engineering + Product | ⬜ |
| 10 | Support team briefed on Vault features and common questions | Customer Success | ⬜ |
| 11 | SMS sender ID registered and tested | Marketing + IT | ⬜ |
| 12 | Analytics/tracking configured for beta signup funnel | Analytics + Engineering | ⬜ |
| 13 | PostHog events instrumented (see `beta-kpi-plan.md` instrumentation table) | Engineering | ⬜ |
| 14 | Beta scoring matrix run against real client data (see `beta-rollout-plan.md`) | Account Manager | ⬜ |
| 15 | Brand concept selected (see `phase2-brand/recommendation.md`) | CEO + Marketing | ⬜ |

---

## Budget Estimation (Order of Magnitude)

> ⚠️ NEEDS CLIENT INPUT: All figures below are estimates. Actual costs depend on vendor selection, team size, and scope.

| Channel | Estimated Cost (SAR) | Notes |
|---|---|---|
| Direct Email | 0 | Existing email infrastructure |
| SMS Blast | 500–2,000 | Depends on list size and UCS-2 segment count (see `sms-blast.md`) |
| WhatsApp Business | 0–500 | WhatsApp Business API fees if using official API |
| LinkedIn Organic | 0 | Organic posts only |
| Twitter/X Organic | 0 | Organic posts only |
| YouTube | 0 (upload) / 30,000–100,000 (video production) | Video production is the largest optional cost |
| In-app Notification | Engineering time only | Estimate 2–3 dev days |
| App Store Updates | 0 | |
| Arabic Tech Press | 0–5,000 | PR newswire distribution fees |
| Press Release | 2,000–5,000 | ZAWYA / AMEinfo distribution |
| Google Ads | 5,000–15,000/month | KSA Arabic search, governance keywords |
| Partner Outreach | 0 (direct cost) | BD team time |
| Webinar | 0–1,000 | Webinar platform (Zoom is free for 40 min) |
| KSA Business Associations | 0–5,000 | Sponsorship / event fees |
| Governance Events | 5,000–20,000 | Conference attendance / sponsorship |
| Referral Program | Engineering time + reward cost | Manual first, then automate |

**Total estimated range:** SAR 12,500–150,000+ (depending on video production and Google Ads commitment)

---

## Contingency Plans

| Risk | Contingency |
|---|---|
| App Store review takes >7 days | Skip App Store channel for launch; submit independently of launch timeline |
| Argaam / tech press doesn't respond | Proceed without press coverage; amplify through LinkedIn + existing client network |
| Video production not ready by launch | Launch without video; use carousel images or GIF screen recordings as placeholder |
| In-app notification engineering delayed | Use email + SMS as primary notification; add in-app post-launch |
| Google Ads account setup blocked | Launch all organic channels first; add paid search in L+1 |

⚠️ NEEDS CLIENT INPUT: Assign specific team members to each owner role, confirm launch timeline, approve budget allocation, and flag any channels that require executive sign-off.
